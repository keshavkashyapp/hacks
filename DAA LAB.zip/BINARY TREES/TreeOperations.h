#ifndef TREEOPERATIONS_H
#define TREEOPERATIONS_H

#include "TreeNode.h"

TreeNode* insertBST(TreeNode* root, int val);
int findMinValue(TreeNode* root);
int maxDepth(TreeNode* root);
void printKDistance(TreeNode* root, int k);
int countLeafNodes(TreeNode* root);

#endif
