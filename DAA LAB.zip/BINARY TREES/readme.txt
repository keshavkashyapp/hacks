g++ TreeOperations.cpp main.cpp -o BinaryTreeLab
./BinaryTreeLab
