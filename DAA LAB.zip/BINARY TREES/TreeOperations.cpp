#include "TreeOperations.h"
#include <iostream>

TreeNode* insertBST(TreeNode* root, int val) {
    if (!root) return new TreeNode(val);
    if (val < root->data)
        root->left = insertBST(root->left, val);
    else
        root->right = insertBST(root->right, val);
    return root;
}

int findMinValue(TreeNode* root) {
    if (!root) return -1;
    while (root->left)
        root = root->left;
    return root->data;
}

int maxDepth(TreeNode* root) {
    if (!root) return 0;
    return 1 + std::max(maxDepth(root->left), maxDepth(root->right));
}

void printKDistance(TreeNode* root, int k) {
    if (!root) return;
    if (k == 0) {
        std::cout << root->data << " ";
        return;
    }
    printKDistance(root->left, k - 1);
    printKDistance(root->right, k - 1);
}

int countLeafNodes(TreeNode* root) {
    if (!root) return 0;
    if (!root->left && !root->right) return 1;
    return countLeafNodes(root->left) + countLeafNodes(root->right);
}
