#include "Base.h"
#include "Number.h"
#include <fstream>
#include <iostream>
#include <sstream>

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cerr << "Usage: ./SmartCalci <basefile> <instructionfile>\n";
        return 1;
    }

    Base base;
    if (base.initializeBase(argv[1]) == -1) {
        std::cerr << "Failed to open base file.\n";
        return 1;
    }

    std::ifstream fin(argv[2]);
    std::ofstream fout("output.txt");
    if (!fin) {
        std::cerr << "Cannot open instruction file.\n";
        return 1;
    }

    std::string line;
    while (std::getline(fin, line)) {
        std::string op = line;

        std::getline(fin, line);
        std::istringstream iss1(line);
        int base1;
        std::string num1;
        iss1 >> base1 >> num1;

        std::getline(fin, line);
        std::istringstream iss2(line);
        int base2;
        std::string num2;
        iss2 >> base2 >> num2;

        Number n1(base1, num1, base);
        Number n2(base2, num2, base);
        Number res;

        if (op == "add")
            res = n1.add(n2, base);
        else if (op == "subtract")
            res = n1.subtract(n2, base);
        else {
            std::cerr << "Unknown operation: " << op << "\n";
            continue;
        }

        fout << num1 << "(" << base1 << ") "
             << (op == "add" ? "+" : "-") << " "
             << num2 << "(" << base2 << ") = "
             << res.toString(base) << "(" << res.base << ")\n";
    }

    fin.close();
    fout.close();
    return 0;
}
