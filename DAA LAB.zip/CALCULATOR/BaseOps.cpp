#include "Base.h"
#include <fstream>
#include <sstream>
#include <iostream>

int Base::initializeBase(const std::string& filename) {
    std::ifstream fin(filename);
    if (!fin) return -1;

    std::string line;
    std::getline(fin, line);
    std::istringstream iss(line);
    std::string token;
    int index = 0;

    while (iss >> token) {
        char c = token[0];
        charToValue[c] = index;
        valueToChar.push_back(c);
        index++;
    }

    maxBase = index;
    return maxBase;
}

int Base::lookup(char c) {
    return charToValue.count(c) ? charToValue[c] : -1;
}

char Base::getChar(int val) {
    return valueToChar[val];
}
