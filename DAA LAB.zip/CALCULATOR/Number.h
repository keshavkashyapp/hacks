#ifndef NUMBER_H
#define NUMBER_H

#include <list>
#include <string>
#include "Base.h"

class Number {
public:
    int base;
    std::list<int> digits; // MSB to LSB

    Number() = default;
    Number(int base, const std::string& numberStr, const Base& b);
    
    Number convertToBase(int newBase, const Base& b) const;
    Number add(const Number& other, const Base& b) const;
    Number subtract(const Number& other, const Base& b) const;

    std::string toString(const Base& b) const;
};

#endif
