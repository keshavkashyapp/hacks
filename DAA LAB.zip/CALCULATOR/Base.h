#ifndef BASE_H
#define BASE_H

#include <map>
#include <vector>
#include <string>

class Base {
public:
    std::map<char, int> charToValue;
    std::vector<char> valueToChar;
    int maxBase;

    int initializeBase(const std::string& filename);
    int lookup(char c);
    char getChar(int val);
};

#endif
