g++ SmartCalci.cpp NumberOps.cpp BaseOps.cpp -o SmartCalci
./SmartCalci base.txt instructions.txt
