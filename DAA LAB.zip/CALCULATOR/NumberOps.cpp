#include "Number.h"
#include <cmath>
#include <algorithm>

Number::Number(int base, const std::string& numberStr, const Base& b) {
    this->base = base;
    for (char c : numberStr) {
        digits.push_back(b.lookup(c));
    }
}

Number Number::convertToBase(int newBase, const Base& b) const {
    long long value = 0;
    for (int d : digits) value = value * base + d;

    Number result;
    result.base = newBase;

    if (value == 0) {
        result.digits.push_back(0);
    } else {
        while (value > 0) {
            result.digits.push_front(value % newBase);
            value /= newBase;
        }
    }

    return result;
}

Number Number::add(const Number& other, const Base& b) const {
    Number a = *this, b2 = other;

    if (a.base != b2.base) {
        if (a.base < b2.base) {
            a = a.convertToBase(b2.base, b);
            return a.add(b2, b);
        } else {
            b2 = b2.convertToBase(a.base, b);
            return a.add(b2, b);
        }
    }

    Number result;
    result.base = a.base;

    auto it1 = a.digits.rbegin();
    auto it2 = b2.digits.rbegin();
    int carry = 0;

    while (it1 != a.digits.rend() || it2 != b2.digits.rend() || carry) {
        int d1 = it1 != a.digits.rend() ? *it1++ : 0;
        int d2 = it2 != b2.digits.rend() ? *it2++ : 0;

        int sum = d1 + d2 + carry;
        carry = sum / a.base;
        result.digits.push_front(sum % a.base);
    }

    return result;
}

Number Number::subtract(const Number& other, const Base& b) const {
    Number a = *this, b2 = other;

    if (a.base != b2.base) {
        if (a.base < b2.base) {
            a = a.convertToBase(b2.base, b);
            return a.subtract(b2, b);
        } else {
            b2 = b2.convertToBase(a.base, b);
            return a.subtract(b2, b);
        }
    }

    Number result;
    result.base = a.base;

    auto it1 = a.digits.rbegin();
    auto it2 = b2.digits.rbegin();
    int borrow = 0;

    while (it1 != a.digits.rend()) {
        int d1 = *it1++ - borrow;
        int d2 = it2 != b2.digits.rend() ? *it2++ : 0;

        if (d1 < d2) {
            d1 += a.base;
            borrow = 1;
        } else {
            borrow = 0;
        }

        result.digits.push_front(d1 - d2);
    }

    // Remove leading zeros
    while (result.digits.size() > 1 && result.digits.front() == 0)
        result.digits.pop_front();

    return result;
}

std::string Number::toString(const Base& b) const {
    std::string result;
    for (int d : digits)
        result += b.getChar(d);
    return result;
}
