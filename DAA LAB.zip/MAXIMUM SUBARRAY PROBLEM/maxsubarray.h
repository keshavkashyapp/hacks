#ifndef MAXSUBARRAY_H
#define MAXSUBARRAY_H

int maxSubArraySum(const int arr[], int n);

#endif
