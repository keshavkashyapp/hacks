g++ -o maxsub main_maxsubarray.cpp maxsubarray.cpp
./maxsub
