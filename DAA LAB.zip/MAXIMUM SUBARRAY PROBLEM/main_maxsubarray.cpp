#include "maxsubarray.h"
#include <iostream>

int main() {
    int arr[] = {-2, -3, 4, -1, -2, 1, 5, -3};
    int n = sizeof(arr) / sizeof(arr[0]);

    std::cout << "Maximum Subarray Sum: " << maxSubArraySum(arr, n) << std::endl;
    return 0;
}
