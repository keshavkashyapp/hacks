g++ main_knapsack.cpp knapsack.cpp -o knapsack
./knapsack