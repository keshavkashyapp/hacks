#include <iostream>
#include "knapsack.h"

int main() {
    int val[] = {60, 100, 120};
    int wt[] = {10, 20, 30};
    int W = 50;
    int n = sizeof(val) / sizeof(val[0]);
    std::cout << "Maximum value in knapsack = " << knapsack(W, wt, val, n) << std::endl;
    return 0;
}
