#ifndef KNAPSACK_H
#define KNAPSACK_H

int knapsack(int W, int wt[], int val[], int n);

#endif
