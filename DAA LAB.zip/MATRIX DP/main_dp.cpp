#include "MatrixChainDP.h"
#include <iostream>
#include <chrono>
#include <fstream>

int main() {
    std::vector<int> dimensions = {30, 35, 15, 5, 10, 20, 25};

    printMatrixInfo(dimensions);

    auto start = std::chrono::high_resolution_clock::now();
    MatrixDPResult result = matrixChainDP(dimensions);
    auto end = std::chrono::high_resolution_clock::now();

    std::chrono::duration<double> duration = end - start;

    std::cout << "\nOptimal Order: " << result.sequence << "\n";
    std::cout << "Minimum Multiplications: " << result.cost << "\n";

    printDPTable(result.m, "M (Cost)");
    printDPTable(result.s, "S (Split)");

    std::cout << "Execution Time: " << duration.count() << " seconds\n";

    std::ofstream out("execution_dp.txt", std::ios::app);
    out << "Input Size: " << dimensions.size() - 1 << ", Time: " << duration.count() << "s\n";
    out.close();

    return 0;
}
