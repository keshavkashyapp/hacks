#include "MatrixChainDP.h"
#include <iostream>
#include <climits>

MatrixDPResult matrixChainDP(const std::vector<int>& dims) {
    int n = dims.size() - 1;
    std::vector<std::vector<int>> m(n, std::vector<int>(n, 0));
    std::vector<std::vector<int>> s(n, std::vector<int>(n, 0));

    for (int l = 2; l <= n; ++l) {
        for (int i = 0; i <= n - l; ++i) {
            int j = i + l - 1;
            m[i][j] = INT_MAX;

            for (int k = i; k < j; ++k) {
                int q = m[i][k] + m[k + 1][j] + dims[i] * dims[k + 1] * dims[j + 1];
                if (q < m[i][j]) {
                    m[i][j] = q;
                    s[i][j] = k;
                }
            }
        }
    }

    MatrixDPResult result;
    result.cost = m[0][n - 1];
    result.sequence = buildOptimalOrder(s, 0, n - 1);
    result.m = m;
    result.s = s;
    return result;
}

std::string buildOptimalOrder(const std::vector<std::vector<int>>& s, int i, int j) {
    if (i == j)
        return "A" + std::to_string(i + 1);
    return "(" + buildOptimalOrder(s, i, s[i][j]) + " x " + buildOptimalOrder(s, s[i][j] + 1, j) + ")";
}

void printMatrixInfo(const std::vector<int>& dimensions) {
    std::cout << "Matrices:\n";
    for (size_t i = 1; i < dimensions.size(); ++i)
        std::cout << "A" << i << ": " << dimensions[i - 1] << " x " << dimensions[i] << "\n";
}

void printDPTable(const std::vector<std::vector<int>>& table, const std::string& name) {
    std::cout << "\n" << name << " Table:\n";
    for (const auto& row : table) {
        for (int val : row)
            std::cout << (val == 0 ? "-" : std::to_string(val)) << "\t";
        std::cout << "\n";
    }
}
