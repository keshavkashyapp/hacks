#ifndef MATRIX_CHAIN_DP_H
#define MATRIX_CHAIN_DP_H

#include <vector>
#include <string>

struct MatrixDPResult {
    std::string sequence;
    int cost;
    std::vector<std::vector<int>> m;
    std::vector<std::vector<int>> s;
};

MatrixDPResult matrixChainDP(const std::vector<int>& dims);
std::string buildOptimalOrder(const std::vector<std::vector<int>>& s, int i, int j);
void printMatrixInfo(const std::vector<int>& dimensions);
void printDPTable(const std::vector<std::vector<int>>& table, const std::string& name);

#endif
