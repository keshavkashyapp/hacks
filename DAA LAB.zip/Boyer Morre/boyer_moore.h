#ifndef BOYER_MOORE_H
#define BOYER_MOORE_H

#include <iostream>
#include <vector>

#define NO_OF_CHARS 256

void badCharHeuristic(const std::string& pattern, std::vector<int>& badChar) {
    for (int i = 0; i < NO_OF_CHARS; i++)
        badChar[i] = -1;

    for (int i = 0; i < pattern.length(); i++)
        badChar[(int)pattern[i]] = i;
}

void BoyerMooreSearch(const std::string& text, const std::string& pattern) {
    int m = pattern.length();
    int n = text.length();

    std::vector<int> badChar(NO_OF_CHARS);
    badCharHeuristic(pattern, badChar);

    int s = 0; // shift of the pattern over text
    while (s <= (n - m)) {
        int j = m - 1;

        while (j >= 0 && pattern[j] == text[s + j])
            j--;

        if (j < 0) {
            std::cout << "Pattern found at index " << s << std::endl;
            s += (s + m < n) ? m - badChar[text[s + m]] : 1;
        } else {
            s += std::max(1, j - badChar[text[s + j]]);
        }
    }
}

#endif
