g++ boyer_moore.cpp -o boyer_moore
./boyer_moore
