#include <iostream>
#include "boyer_moore.h"

int main() {
    std::string text = "ababcabcabababd";
    std::string pattern = "ababd";

    std::cout << "Running Boyer-Moore String Matching:\n";
    BoyerMooreSearch(text, pattern);

    return 0;
}
