#ifndef KRUSKAL_H
#define KRUSKAL_H

void kruskalMST(int V, int E, int edges[][3]);

#endif
