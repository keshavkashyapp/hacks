g++ main_kruskal.cpp kruskal.cpp -o kruskal
./kruskal