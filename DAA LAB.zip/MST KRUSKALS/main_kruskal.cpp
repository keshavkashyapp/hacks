#include "kruskal.h"

int main() {
    int V = 4, E = 5;
    int edges[5][3] = {
        {0, 1, 10},
        {0, 2, 6},
        {0, 3, 5},
        {1, 3, 15},
        {2, 3, 4}
    };

    kruskalMST(V, E, edges);
    return 0;
}
