#include <iostream>
#include <algorithm>
#include "kruskal.h"

struct Subset {
    int parent;
    int rank;
};

int find(Subset subsets[], int i) {
    if (subsets[i].parent != i)
        subsets[i].parent = find(subsets, subsets[i].parent);
    return subsets[i].parent;
}

void Union(Subset subsets[], int x, int y) {
    int xroot = find(subsets, x);
    int yroot = find(subsets, y);
    if (subsets[xroot].rank < subsets[yroot].rank)
        subsets[xroot].parent = yroot;
    else if (subsets[xroot].rank > subsets[yroot].rank)
        subsets[yroot].parent = xroot;
    else {
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
    }
}

bool compare(const int a[3], const int b[3]) {
    return a[2] < b[2];
}

void kruskalMST(int V, int E, int edges[][3]) {
    std::sort(edges, edges + E, compare);
    Subset* subsets = new Subset[V];

    for (int v = 0; v < V; ++v) {
        subsets[v].parent = v;
        subsets[v].rank = 0;
    }

    std::cout << "Edge \tWeight\n";
    int e = 0, i = 0;
    while (e < V - 1 && i < E) {
        int* next_edge = edges[i++];
        int x = find(subsets, next_edge[0]);
        int y = find(subsets, next_edge[1]);

        if (x != y) {
            std::cout << next_edge[0] << " - " << next_edge[1] << "\t" << next_edge[2] << std::endl;
            Union(subsets, x, y);
            e++;
        }
    }

    delete[] subsets;
}
