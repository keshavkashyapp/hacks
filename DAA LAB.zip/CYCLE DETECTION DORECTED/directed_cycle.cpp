#include "directed_cycle.h"
#include <vector>
#include <queue>

bool dfsDirectedUtil(int v, std::vector<bool>& visited, std::vector<bool>& recStack, const std::vector<std::vector<int>>& adj) {
    visited[v] = true;
    recStack[v] = true;

    for (int neighbor : adj[v]) {
        if (!visited[neighbor] && dfsDirectedUtil(neighbor, visited, recStack, adj))
            return true;
        else if (recStack[neighbor])
            return true;
    }

    recStack[v] = false;
    return false;
}

bool hasCycleDFSDirected(int V, const std::vector<std::vector<int>>& adj) {
    std::vector<bool> visited(V, false), recStack(V, false);
    for (int i = 0; i < V; ++i)
        if (!visited[i] && dfsDirectedUtil(i, visited, recStack, adj))
            return true;
    return false;
}

bool hasCycleBFSDirected(int V, const std::vector<std::vector<int>>& adj) {
    std::vector<int> in_degree(V, 0);
    for (int u = 0; u < V; u++)
        for (int v : adj[u])
            in_degree[v]++;

    std::queue<int> q;
    for (int i = 0; i < V; i++)
        if (in_degree[i] == 0)
            q.push(i);

    int count = 0;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        count++;
        for (int v : adj[u])
            if (--in_degree[v] == 0)
                q.push(v);
    }

    return count != V;
}
