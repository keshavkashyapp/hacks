#include <iostream>
#include "directed_cycle.h"

int main() {
    int V = 4;
    std::vector<std::vector<int>> adj(V);
    adj[0] = {1};
    adj[1] = {2};
    adj[2] = {3};
    adj[3] = {1}; // cycle

    std::cout << "DFS (directed) cycle detection: " << (hasCycleDFSDirected(V, adj) ? "Cycle found" : "No cycle") << std::endl;
    std::cout << "BFS (Kahn's) cycle detection: " << (hasCycleBFSDirected(V, adj) ? "Cycle found" : "No cycle") << std::endl;
    return 0;
}
