#ifndef DIRECTED_CYCLE_H
#define DIRECTED_CYCLE_H

#include <vector>

bool hasCycleDFSDirected(int V, const std::vector<std::vector<int>>& adj);
bool hasCycleBFSDirected(int V, const std::vector<std::vector<int>>& adj);

#endif
