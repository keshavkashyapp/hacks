#ifndef LCS_DP_H
#define LCS_DP_H

#include <string>
#include <vector>

struct LCSResult {
    std::string lcs;
    std::vector<std::vector<int>> C;
    std::vector<std::vector<char>> B;
};

LCSResult lcsDynamicProgramming(const std::string& X, const std::string& Y);
std::string buildLCS(const std::vector<std::vector<char>>& B, const std::string& X, int i, int j);
void printTable(const std::vector<std::vector<int>>& table, const std::string& name);

#endif
