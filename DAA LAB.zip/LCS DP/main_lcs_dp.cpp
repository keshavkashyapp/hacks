#include "LCS_DP.h"
#include <iostream>
#include <chrono>
#include <fstream>

int main() {
    std::string X = "abcde";
    std::string Y = "acebd";

    auto start = std::chrono::high_resolution_clock::now();
    LCSResult result = lcsDynamicProgramming(X, Y);
    auto end = std::chrono::high_resolution_clock::now();

    std::chrono::duration<double> duration = end - start;

    std::cout << "X: " << X << "\nY: " << Y << "\n";
    std::cout << "LCS (DP): " << result.lcs << " (Length: " << result.lcs.length() << ")\n";

    printTable(result.C, "C (Length)");
    std::cout << "Execution Time: " << duration.count() << " seconds\n";

    std::ofstream out("execution_lcs_dp.txt", std::ios::app);
    out << "Input Length: " << X.length() << ", Time: " << duration.count() << "s\n";
    out.close();

    return 0;
}
