#include "LCS_DP.h"
#include <iostream>

LCSResult lcsDynamicProgramming(const std::string& X, const std::string& Y) {
    int m = X.length();
    int n = Y.length();

    std::vector<std::vector<int>> C(m + 1, std::vector<int>(n + 1, 0));
    std::vector<std::vector<char>> B(m + 1, std::vector<char>(n + 1, '0'));

    for (int i = 1; i <= m; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (X[i - 1] == Y[j - 1]) {
                C[i][j] = C[i - 1][j - 1] + 1;
                B[i][j] = 'D'; // Diagonal
            } else if (C[i - 1][j] >= C[i][j - 1]) {
                C[i][j] = C[i - 1][j];
                B[i][j] = 'U'; // Up
            } else {
                C[i][j] = C[i][j - 1];
                B[i][j] = 'L'; // Left
            }
        }
    }

    LCSResult result;
    result.lcs = buildLCS(B, X, m, n);
    result.C = C;
    result.B = B;
    return result;
}

std::string buildLCS(const std::vector<std::vector<char>>& B, const std::string& X, int i, int j) {
    if (i == 0 || j == 0)
        return "";
    if (B[i][j] == 'D')
        return buildLCS(B, X, i - 1, j - 1) + X[i - 1];
    else if (B[i][j] == 'U')
        return buildLCS(B, X, i - 1, j);
    else
        return buildLCS(B, X, i, j - 1);
}

void printTable(const std::vector<std::vector<int>>& table, const std::string& name) {
    std::cout << "\n" << name << " Table:\n";
    for (const auto& row : table) {
        for (int val : row)
            std::cout << val << "\t";
        std::cout << "\n";
    }
}
