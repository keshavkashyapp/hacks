#ifndef PRIM_H
#define PRIM_H

void primMST(int graph[5][5]);

#endif
