g++ main_prim.cpp prim.cpp -o prim
./prim