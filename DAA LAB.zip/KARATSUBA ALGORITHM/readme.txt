g++ -o karatsuba main_karatsuba.cpp karatsuba.cpp
./karatsuba
