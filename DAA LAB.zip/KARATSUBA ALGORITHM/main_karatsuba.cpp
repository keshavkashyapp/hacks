#include "karatsuba.h"
#include <iostream>

int main() {
    long long x = 1234;
    long long y = 5678;

    std::cout << "Karatsuba Result: " << karatsuba(x, y) << std::endl;
    return 0;
}
