#ifndef KARATSUBA_H
#define KARATSUBA_H

long long karatsuba(long long x, long long y);

#endif
