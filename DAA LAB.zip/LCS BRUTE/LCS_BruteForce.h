#ifndef LCS_BRUTEFORCE_H
#define LCS_BRUTEFORCE_H

#include <string>
#include <vector>

std::string longestCommonSubsequenceBruteForce(const std::string& X, const std::string& Y);
bool isSubsequence(const std::string& sub, const std::string& main);
void generateAllSubsequences(const std::string& str, std::vector<std::string>& result);

#endif
