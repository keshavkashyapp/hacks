#include "LCS_BruteForce.h"
#include <iostream>
#include <chrono>
#include <fstream>

int main() {
    std::string X = "abcde";
    std::string Y = "acebd";

    auto start = std::chrono::high_resolution_clock::now();
    std::string lcs = longestCommonSubsequenceBruteForce(X, Y);
    auto end = std::chrono::high_resolution_clock::now();

    std::chrono::duration<double> duration = end - start;

    std::cout << "X: " << X << "\nY: " << Y << "\n";
    std::cout << "LCS (Brute Force): " << lcs << " (Length: " << lcs.length() << ")\n";
    std::cout << "Time Taken: " << duration.count() << " seconds\n";

    std::ofstream out("execution_lcs_brute.txt", std::ios::app);
    out << "Input Length: " << X.length() << ", Time: " << duration.count() << "s\n";
    out.close();

    return 0;
}
