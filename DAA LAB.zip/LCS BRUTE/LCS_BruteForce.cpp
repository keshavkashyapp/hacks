#include "LCS_BruteForce.h"
#include <iostream>

void generateAllSubsequences(const std::string& str, std::vector<std::string>& result) {
    int n = str.length();
    int total = 1 << n;

    for (int i = 1; i < total; ++i) {
        std::string sub;
        for (int j = 0; j < n; ++j) {
            if (i & (1 << j))
                sub += str[j];
        }
        result.push_back(sub);
    }
}

bool isSubsequence(const std::string& sub, const std::string& main) {
    int i = 0, j = 0;
    while (i < sub.size() && j < main.size()) {
        if (sub[i] == main[j])
            ++i;
        ++j;
    }
    return i == sub.size();
}

std::string longestCommonSubsequenceBruteForce(const std::string& X, const std::string& Y) {
    std::vector<std::string> allSub;
    generateAllSubsequences(X, allSub);

    std::string longest;
    for (const auto& sub : allSub) {
        if (isSubsequence(sub, Y) && sub.length() > longest.length()) {
            longest = sub;
        }
    }
    return longest;
}
