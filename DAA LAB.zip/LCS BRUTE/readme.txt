build_lcs_brute.bat
LCS_Brute.exe
