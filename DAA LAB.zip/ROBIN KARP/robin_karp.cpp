#include <iostream>
#include "rabin_karp.h"

int main() {
    std::string text = "ababcabcabababd";
    std::string pattern = "ababd";

    std::cout << "Running Rabin-Karp String Matching:\n";
    RabinKarpSearch(text, pattern);

    return 0;
}
