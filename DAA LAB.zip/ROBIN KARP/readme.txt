g++ rabin_karp.cpp -o rabin_karp
./rabin_karp