#include <iostream>
#include "undirected_cycle.h"

int main() {
    int V = 5;
    std::vector<std::vector<int>> adj(V);
    adj[0] = {1, 4};
    adj[1] = {0, 2};
    adj[2] = {1, 3};
    adj[3] = {2};
    adj[4] = {0};

    std::cout << "DFS cycle detection: " << (hasCycleDFS(V, adj) ? "Cycle found" : "No cycle") << std::endl;
    std::cout << "BFS cycle detection: " << (hasCycleBFS(V, adj) ? "Cycle found" : "No cycle") << std::endl;
    return 0;
}
