#ifndef UNDIRECTED_CYCLE_H
#define UNDIRECTED_CYCLE_H

#include <vector>

bool hasCycleDFS(int V, const std::vector<std::vector<int>>& adj);
bool hasCycleBFS(int V, const std::vector<std::vector<int>>& adj);

#endif
