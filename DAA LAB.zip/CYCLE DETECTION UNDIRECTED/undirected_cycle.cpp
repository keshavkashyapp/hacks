#include "undirected_cycle.h"
#include <vector>
#include <queue>

bool dfsUtil(int v, int parent, std::vector<bool>& visited, const std::vector<std::vector<int>>& adj) {
    visited[v] = true;
    for (int neighbor : adj[v]) {
        if (!visited[neighbor]) {
            if (dfsUtil(neighbor, v, visited, adj)) return true;
        } else if (neighbor != parent) {
            return true;
        }
    }
    return false;
}

bool hasCycleDFS(int V, const std::vector<std::vector<int>>& adj) {
    std::vector<bool> visited(V, false);
    for (int i = 0; i < V; i++) {
        if (!visited[i]) {
            if (dfsUtil(i, -1, visited, adj)) return true;
        }
    }
    return false;
}

bool hasCycleBFS(int V, const std::vector<std::vector<int>>& adj) {
    std::vector<bool> visited(V, false);
    std::queue<std::pair<int, int>> q;

    for (int i = 0; i < V; i++) {
        if (!visited[i]) {
            q.push({i, -1});
            visited[i] = true;

            while (!q.empty()) {
                int node = q.front().first;
                int parent = q.front().second;
                q.pop();

                for (int neighbor : adj[node]) {
                    if (!visited[neighbor]) {
                        visited[neighbor] = true;
                        q.push({neighbor, node});
                    } else if (neighbor != parent) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}
