#include <iostream>
#include "n_queens.h"

int main() {
    int n;
    std::cout << "Enter number of queens (N): ";
    std::cin >> n;

    solveNQueens(n);

    return 0;
}
