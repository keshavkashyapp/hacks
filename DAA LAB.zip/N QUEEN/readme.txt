g++ n_queens.cpp -o n_queens
./n_queens
