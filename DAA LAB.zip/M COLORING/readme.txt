g++ m_coloring.cpp -o m_coloring
./m_coloring
