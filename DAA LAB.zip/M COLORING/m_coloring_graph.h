#ifndef M_COLORING_H
#define M_COLORING_H

#include <iostream>
#include <vector>

bool isSafe(int node, int color, const std::vector<std::vector<int>>& graph, const std::vector<int>& colors, int n) {
    for (int i = 0; i < n; i++) {
        if (graph[node][i] && colors[i] == color)
            return false;
    }
    return true;
}

bool graphColoringUtil(int node, const std::vector<std::vector<int>>& graph, std::vector<int>& colors, int m, int n) {
    if (node == n) return true;

    for (int c = 1; c <= m; c++) {
        if (isSafe(node, c, graph, colors, n)) {
            colors[node] = c;
            if (graphColoringUtil(node + 1, graph, colors, m, n)) return true;
            colors[node] = 0; // backtrack
        }
    }
    return false;
}

void graphColoring(const std::vector<std::vector<int>>& graph, int m, int n) {
    std::vector<int> colors(n, 0);

    if (!graphColoringUtil(0, graph, colors, m, n)) {
        std::cout << "No solution exists with " << m << " colors.\n";
        return;
    }

    std::cout << "Solution using " << m << " colors:\n";
    for (int i = 0; i < n; i++)
        std::cout << "Vertex " << i << " ---> Color " << colors[i] << std::endl;
}

#endif
