#include <iostream>
#include "m_coloring.h"

int main() {
    int n = 4; // Number of vertices
    int m = 3; // Number of colors

    // Graph represented as adjacency matrix
    std::vector<std::vector<int>> graph = {
        {0, 1, 1, 1},
        {1, 0, 1, 0},
        {1, 1, 0, 1},
        {1, 0, 1, 0}
    };

    std::cout << "Running M-Coloring (Graph Coloring) Problem:\n";
    graphColoring(graph, m, n);

    return 0;
}
