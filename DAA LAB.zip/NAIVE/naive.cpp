#include <iostream>
#include "naive.h"

int main() {
    std::string text = "ababcabcabababd";
    std::string pattern = "ababd";

    std::cout << "Running Naive String Matching:\n";
    naiveSearch(text, pattern);

    return 0;
}
