#ifndef NAIVE_H
#define NAIVE_H

#include <iostream>

void naiveSearch(const std::string& text, const std::string& pattern) {
    int n = text.length(), m = pattern.length();
    for (int i = 0; i <= n - m; i++) {
        int j = 0;
        while (j < m && text[i + j] == pattern[j]) j++;
        if (j == m)
            std::cout << "Pattern found at index " << i << std::endl;
    }
}

#endif
