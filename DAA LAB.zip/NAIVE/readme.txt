g++ naive.cpp -o naive
./naive