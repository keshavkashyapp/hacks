#include "MatrixChain.h"
#include <iostream>

void generateAllOrders(const std::vector<int>& dims, int i, int j,
                       std::vector<std::vector<int>>& cost,
                       std::vector<std::vector<std::string>>& expr) {
    if (i == j) {
        expr[i][j] = "A" + std::to_string(i + 1);
        cost[i][j] = 0;
        return;
    }

    cost[i][j] = INT_MAX;

    for (int k = i; k < j; ++k) {
        generateAllOrders(dims, i, k, cost, expr);
        generateAllOrders(dims, k + 1, j, cost, expr);

        int q = cost[i][k] + cost[k + 1][j] + dims[i] * dims[k + 1] * dims[j + 1];
        if (q < cost[i][j]) {
            cost[i][j] = q;
            expr[i][j] = "(" + expr[i][k] + " x " + expr[k + 1][j] + ")";
        }
    }
}

MatrixChainResult matrixChainExhaustive(const std::vector<int>& dimensions) {
    int n = dimensions.size() - 1;
    std::vector<std::vector<int>> cost(n, std::vector<int>(n, 0));
    std::vector<std::vector<std::string>> expr(n, std::vector<std::string>(n, ""));

    generateAllOrders(dimensions, 0, n - 1, cost, expr);

    return { expr[0][n - 1], cost[0][n - 1] };
}

void printMatrixInfo(const std::vector<int>& dimensions) {
    std::cout << "Matrices:\n";
    for (size_t i = 1; i < dimensions.size(); ++i) {
        std::cout << "A" << i << ": " << dimensions[i - 1] << " x " << dimensions[i] << "\n";
    }
}
