build.bat
MatrixExhaustive.exe