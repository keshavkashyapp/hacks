#ifndef MATRIX_CHAIN_H
#define MATRIX_CHAIN_H

#include <vector>
#include <string>
#include <climits>

struct MatrixChainResult {
    std::string sequence;
    int cost;
};

MatrixChainResult matrixChainExhaustive(const std::vector<int>& dimensions);
void generateAllOrders(const std::vector<int>& dims, int i, int j,
                       std::vector<std::vector<int>>& cost,
                       std::vector<std::vector<std::string>>& expr);
void printMatrixInfo(const std::vector<int>& dimensions);

#endif
