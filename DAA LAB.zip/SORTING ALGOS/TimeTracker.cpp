#include "TimeTracker.h"

long getTimeMicroseconds() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (tv.tv_sec * 1e6) + tv.tv_usec;
}
