#ifndef TIMETRACKER_H
#define TIMETRACKER_H

#include <sys/time.h>

long getTimeMicroseconds();

#endif
