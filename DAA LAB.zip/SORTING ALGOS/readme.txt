build.bat
SortProfiler.exe
gprof SortProfiler.exe gmon.out > gprof_output.txt
