#include "SortingAlgos.h"
#include "TimeTracker.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

std::vector<int> readArrayFromFile(const std::string& filename) {
    std::ifstream fin(filename);
    std::vector<int> arr;
    int num;
    while (fin >> num) arr.push_back(num);
    return arr;
}

void measureAndLog(const std::string& name, void (*sortFn)(std::vector<int>&), std::vector<int> arr, std::ofstream& log) {
    long start = getTimeMicroseconds();
    sortFn(arr);
    long end = getTimeMicroseconds();
    log << name << " " << arr.size() << " " << (end - start) / 1000000.0 << "\n";
}

int main() {
    std::string filename = "input.txt";
    std::ofstream log("sort_times.txt");

    std::vector<int> original = readArrayFromFile(filename);
    measureAndLog("BubbleSort", bubbleSort, original, log);
    measureAndLog("SelectionSort", selectionSort, original, log);
    measureAndLog("InsertionSort", insertionSort, original, log);

    std::vector<int> arr1 = original;
    long start = getTimeMicroseconds();
    mergeSort(arr1, 0, arr1.size() - 1);
    long end = getTimeMicroseconds();
    log << "MergeSort " << arr1.size() << " " << (end - start) / 1000000.0 << "\n";

    std::vector<int> arr2 = original;
    start = getTimeMicroseconds();
    quickSort(arr2, 0, arr2.size() - 1);
    end = getTimeMicroseconds();
    log << "QuickSort " << arr2.size() << " " << (end - start) / 1000000.0 << "\n";

    log.close();
    return 0;
}
