#include <iostream>
#include "kmp.h"

int main() {
    std::string text = "ababcabcabababd";
    std::string pattern = "ababd";

    std::cout << "Running KMP String Matching:\n";
    KMPSearch(text, pattern);

    return 0;
}
