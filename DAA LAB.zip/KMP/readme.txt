g++ kmp.cpp -o kmp
./kmp
