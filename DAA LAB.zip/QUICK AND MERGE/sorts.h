#ifndef SORTS_H
#define SORTS_H

void quickSort(int arr[], int low, int high);
void mergeSort(int arr[], int l, int r);

#endif
