#include <iostream>
#include "sorts.h"

void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++) std::cout << arr[i] << " ";
    std::cout << std::endl;
}

int main() {
    int arr1[] = {10, 7, 8, 9, 1, 5};
    int arr2[] = {10, 7, 8, 9, 1, 5};
    int n = sizeof(arr1) / sizeof(arr1[0]);

    quickSort(arr1, 0, n - 1);
    std::cout << "Quick Sorted array: ";
    printArray(arr1, n);

    mergeSort(arr2, 0, n - 1);
    std::cout << "Merge Sorted array: ";
    printArray(arr2, n);

    return 0;
}
