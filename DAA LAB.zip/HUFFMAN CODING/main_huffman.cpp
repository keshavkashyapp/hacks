#include "huffman.h"

int main() {
    std::vector<char> chars = {'a', 'b', 'c', 'd', 'e', 'f'};
    std::vector<int> freqs = {5, 9, 12, 13, 16, 45};

    huffmanCoding(chars, freqs);
    return 0;
}
