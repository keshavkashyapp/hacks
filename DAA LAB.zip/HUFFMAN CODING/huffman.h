#ifndef HUFFMAN_H
#define HUFFMAN_H

#include <vector>
#include <string>
#include <unordered_map>

void huffmanCoding(const std::vector<char>& chars, const std::vector<int>& freqs);

#endif
