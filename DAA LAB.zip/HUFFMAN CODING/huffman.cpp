#include "huffman.h"
#include <queue>
#include <iostream>

struct Node {
    char ch;
    int freq;
    Node* left;
    Node* right;
    Node(char c, int f) : ch(c), freq(f), left(nullptr), right(nullptr) {}
};

struct Compare {
    bool operator()(Node* a, Node* b) {
        return a->freq > b->freq;
    }
};

void printCodes(Node* root, const std::string& str) {
    if (!root) return;
    if (!root->left && !root->right)
        std::cout << root->ch << ": " << str << std::endl;
    printCodes(root->left, str + "0");
    printCodes(root->right, str + "1");
}

void huffmanCoding(const std::vector<char>& chars, const std::vector<int>& freqs) {
    std::priority_queue<Node*, std::vector<Node*>, Compare> pq;

    for (size_t i = 0; i < chars.size(); ++i)
        pq.push(new Node(chars[i], freqs[i]));

    while (pq.size() > 1) {
        Node* left = pq.top(); pq.pop();
        Node* right = pq.top(); pq.pop();
        Node* merged = new Node('$', left->freq + right->freq);
        merged->left = left;
        merged->right = right;
        pq.push(merged);
    }

    printCodes(pq.top(), "");
}
