g++ -o huffman main_huffman.cpp huffman.cpp
./huffman
