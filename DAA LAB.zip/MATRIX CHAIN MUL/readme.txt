g++ -o matrixchain main_matrixchain.cpp matrixchain.cpp
./matrixchain
