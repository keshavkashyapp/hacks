#include "matrixchain.h"
#include <iostream>

int main() {
    int arr[] = {1, 2, 3, 4};
    int n = sizeof(arr) / sizeof(arr[0]);

    std::cout << "Minimum number of multiplications: " << matrixChainOrder(arr, n) << std::endl;
    return 0;
}
