#ifndef MATRIXCHAIN_H
#define MATRIXCHAIN_H

int matrixChainOrder(int p[], int n);

#endif
