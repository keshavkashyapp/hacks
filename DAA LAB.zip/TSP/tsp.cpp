#include "tsp.h"
#include <iostream>
#include <vector>
#include <limits.h>

int tspUtil(int graph[][4], std::vector<bool>& visited, int pos, int n, int count, int cost, int start, int& ans) {
    if (count == n && graph[pos][start]) {
        ans = std::min(ans, cost + graph[pos][start]);
        return ans;
    }

    for (int i = 0; i < n; i++) {
        if (!visited[i] && graph[pos][i]) {
            visited[i] = true;
            tspUtil(graph, visited, i, n, count + 1, cost + graph[pos][i], start, ans);
            visited[i] = false;
        }
    }
    return ans;
}

void tsp(int graph[][4], int V) {
    std::vector<bool> visited(V, false);
    visited[0] = true;
    int ans = INT_MAX;
    tspUtil(graph, visited, 0, V, 1, 0, 0, ans);
    std::cout << "Minimum cost of TSP: " << ans << std::endl;
}
