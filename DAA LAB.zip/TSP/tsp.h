#ifndef TSP_H
#define TSP_H

void tsp(int graph[][4], int V);

#endif
