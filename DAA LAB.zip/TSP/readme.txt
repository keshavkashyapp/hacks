g++ -o tsp main_tsp.cpp tsp.cpp
./tsp
