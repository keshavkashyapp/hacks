// main.cpp
#include <iostream>
#include "calculator.h"

int main() {
    int x = 7, y = 3;

    std::cout << "Add: " << add(x, y) << std::endl;
    std::cout << "Subtract: " << subtract(x, y) << std::endl;

    return 0;
}
