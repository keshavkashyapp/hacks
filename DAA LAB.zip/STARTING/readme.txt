build.bat
SmartCalci.exe
